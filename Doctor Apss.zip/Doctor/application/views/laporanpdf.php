<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <table>
        <tr>
            <th>No</th>
            <th>Nama Lengkap</th>
            <th>Jenis Kelamin</th>
            <th>Agama</th>
            <th>Nomor Telepon</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Aksi</th>
        </tr>
        <?php
        $no = 1;
        foreach ($dashboard as $dt) :
        ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $dt->nama_lengkap ?></td>
                <td><?= $dt->jenis_kelamin ?></td>
                <td><?= $dt->agama ?></td>
                <td><?= $dt->no_hp ?></td>
                <td><?= $dt->email ?></td>
                <td><?= $dt->alamat ?></td>
            </tr>
        <?php
        endforeach;
        ?>
    </table>

</body>

</html>